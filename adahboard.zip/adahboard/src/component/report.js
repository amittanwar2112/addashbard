import  React  from  'react'

function  Report(){
	
	return ( 
	<div>
        <h2>inside report</h2>
    </div>
);
}


export default  Report